#include <stdio.h>
#include <stdbool.h>

int main() {
    int age;
    int pizza;
    char exercise_input;
    bool exercise;

    
    printf("Enter your age: \n");
    scanf("%d", &age);

    printf("Enter how many pizzas you eat a week: \n");
    scanf("%d", &pizza);

    printf("Do you workout? (Y is for yes, N is for no): \n");
    scanf(" %c", &exercise_input); 

    
    exercise = (exercise_input == 'Y' || exercise_input == 'y');

   
    if (age <= 25) {
        if (pizza >= 0 && pizza <= 2) {
            printf("You are fit.\n");
        } else {
            printf("You are not fit.\n");
        }
    } else if (age >= 26 && age <= 35) {
        if (pizza >= 0 && pizza <= 2) {
            if (exercise) {
                printf("You are fit.\n");
            } else {
                printf("You are not fit.\n");
            }
        } else {
            printf("You are not fit.\n");
        }
    } else if (age >= 36) {
        if (pizza >= 0 && pizza <= 3) {
            if (exercise) {
                printf("You are fit.\n");
            } else {
                printf("You are not fit.\n");
            }
        } else {
            printf("You are not fit.\n");
        }
    }

    return 0;
}

