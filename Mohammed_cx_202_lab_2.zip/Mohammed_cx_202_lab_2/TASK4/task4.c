#include <stdio.h>

int main() {

	int units;
	int bill;

	printf("Enter the number of electricity units consumed: \n");
	scanf("%d", &units);



	if (units >= 100 && units <= 200) {

		bill = 18*units;
		printf("The electricity bill is: %d\n", bill);
	}
	else if (units > 200 && units <= 250) {

		bill = 38*units-2000;
		printf("The electricity bill is: %d\n", bill);
	}
	else if (units > 250 && units <= 350) {

		bill = 30*units;
		printf("The electricity bill is: %d\n", bill);
	}
	else if (units > 350 && units < 400) {

		bill = 130*units-35000;
		printf("The electricity bill is: %d\n", bill);
	}
	else if (units >= 400) {

		bill = 140*units-40000;
		printf("The electricity bill is: %d\n", bill);
	}




	return 0;


}
