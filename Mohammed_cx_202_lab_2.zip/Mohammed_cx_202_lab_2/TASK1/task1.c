#include <stdio.h>

int main() {

	char character;

	printf("Please enter the character: \n");
	scanf("%c", &character);



	switch (character) {


		case 'a':
		case 'A':
			printf("The character is vowel\n");
			break;

		case 'e':
		case 'E':
			printf("The character is vowel\n");
			break;

		case 'i':
		case 'I':
			printf("The character is vowel\n");
			break;

		case 'o':
		case 'O':
			printf("The character is vowel\n");
			break;

		case 'u':
		case 'U':
			printf("The character is vowel\n");
			break;

		default:
			printf("It's a consonant \n");
			break;
	}

	return 0;
}



