#include <stdio.h>


int main() {

	int grade;


	printf("Please enter the grade: \n");
	scanf("%d", &grade);



	if (grade > 73) {

		printf("Congrats!! You got A !! \n");
	}
	else if (grade > 68) {
		printf("You got B+\n");
	}

	else if (grade > 63) {
		printf("You got B\n");
	}
	else if (grade > 58) {
		printf("You got C+\n");
	}
	else if (grade > 52) {
		printf("You got C\n");
	}
	else if (grade > 47) {
		printf("You got D+\n");
	}
	else if (grade > 41) {
		printf("You got D\n");
	}
	else
		printf("You got F\n");



	return 0;


}
