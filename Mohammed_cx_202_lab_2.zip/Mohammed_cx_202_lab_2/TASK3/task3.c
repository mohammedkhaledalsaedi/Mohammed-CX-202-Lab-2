#include <stdio.h>

int main() {

    float distance;
    char mean;
    float time;

    int W = 5;
    int B = 18;
    int C = 60;

    printf("Enter the distance in KM: \n");
    scanf("%f", &distance);

    printf("Enter the Transport Mean (W for Walking, B for Bicycle, C for Car): \n");
    scanf(" %c", &mean);

    switch (mean) {
        case 'W':
        case 'w':
            time = distance / W;
            printf("It takes around %.2f hours by walking.\n", time);
            break;

        case 'B':
        case 'b':
            time = distance / B;
            printf("It takes around %.2f hours by bicycle.\n", time);
            break;

        case 'C':
        case 'c':
            time = distance / C;
            printf("It takes around %.2f hours by car.\n", time);
            break;

        default:
            printf("Invalid transport mean entered.\n");
            break;
    }

    return 0;
}

